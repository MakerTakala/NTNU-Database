<?php

// ******** update your personal settings ******** 
$servername = "140.122.184.125:3307";
$username = "team3";
$password = ".n4mUvx*bJSujVck";
$dbname = "team3";

// Connecting to and selecting a MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

?>

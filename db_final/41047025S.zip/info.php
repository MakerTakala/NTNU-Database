<?php
    phpinfo();
?>